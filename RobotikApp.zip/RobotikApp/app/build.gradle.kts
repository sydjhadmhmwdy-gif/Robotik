plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.rubatik.ir"
    compileSdk = 34

    defaultConfig {
        // باید دقیقاً همون نام پکیجی باشه که توی پنل مایکت ثبت کردی
        applicationId = "com.rubatik.ir"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        // تنظیمات لازم کتابخونه‌ی خرید مایکت
        manifestPlaceholders["marketApplicationId"] = "ir.mservices.market"
        manifestPlaceholders["marketBindAddress"] = "ir.mservices.market.InAppBillingService.BIND"
        manifestPlaceholders["marketPermission"] = "ir.mservices.market.BILLING"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.webkit:webkit:1.11.0")
    // کتابخونه‌ی رسمی خرید درون‌برنامه‌ای مایکت (از jitpack)
    implementation("com.github.myketstore:myket-billing-client:1.15")
}
