package com.rubatik.ir

import android.annotation.SuppressLint
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.webkit.WebViewAssetLoader

class MainActivity : AppCompatActivity() {

    companion object {
        private const val ASSET_HOST = "appassets.androidplatform.net"
        private const val START_URL = "https://$ASSET_HOST/assets/index.html"
    }

    private lateinit var webView: WebView
    private var bridge: MyketBridge? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        webView = WebView(this)
        setContentView(webView)

        // فایل‌های داخل assets از آدرس https مجازی سرو می‌شن (برای localStorage و کپی کردن کلیپ‌بورد لازمه)
        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
        }

        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView, request: WebResourceRequest
            ): WebResourceResponse? = assetLoader.shouldInterceptRequest(request.url)

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val uri = request.url
                if (uri.host == ASSET_HOST) return false          // صفحه‌ی خود اپ
                if (uri.scheme == "about") return true            // about:blank و مشابه رو نادیده بگیر
                openExternal(uri)                                 // لینک روبیکا، myket://comment و ... بیرون از اپ باز بشن
                return true
            }
        }

        // پل خرید مایکت؛ چون فقط صفحه‌ی خود اپ لود می‌شه (لینک‌های بیرونی جدا باز می‌شن) امنه
        bridge = MyketBridge(this, webView).also {
            webView.addJavascriptInterface(it, "MyketBridge")
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                // اگه توی صفحه‌ی اصلی نیستیم، برگرد صفحه‌ی اصلی؛ وگرنه از اپ خارج شو
                webView.evaluateJavascript(
                    "(function(){var a=document.querySelector('.screen.active');return a?a.id:''})()"
                ) { res ->
                    val id = res?.trim('"') ?: ""
                    if (id.isNotEmpty() && id != "screen-main") {
                        webView.evaluateJavascript("go('screen-main')", null)
                    } else {
                        isEnabled = false
                        onBackPressedDispatcher.onBackPressed()
                    }
                }
            }
        })

        if (savedInstanceState == null) webView.loadUrl(START_URL) else webView.restoreState(savedInstanceState)
    }

    private fun openExternal(uri: Uri) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, "برنامه‌ی مناسب برای باز کردن این لینک پیدا نشد", Toast.LENGTH_SHORT).show()
        }
    }

    // نتیجه‌ی صفحه‌ی پرداخت مایکت باید به کتابخونه برسه
    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (bridge?.handleActivityResult(requestCode, resultCode, data) != true) {
            @Suppress("DEPRECATION")
            super.onActivityResult(requestCode, resultCode, data)
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        webView.saveState(outState)
    }

    override fun onDestroy() {
        bridge?.dispose()
        webView.destroy()
        super.onDestroy()
    }
}
