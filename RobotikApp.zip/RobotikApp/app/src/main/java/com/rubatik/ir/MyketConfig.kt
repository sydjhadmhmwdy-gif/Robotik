package com.rubatik.ir

object MyketConfig {
    // کلید عمومی RSA رو از پنل مایکت (developer.myket.ir ← اپ ← بخش خرید درون‌برنامه‌ای) کپی کن و اینجا بذار
    const val RSA_KEY = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCkxuLelzWl2j8H5cG4i5JjkXcYtc1ohiEcaQbwWk6P0ydhSlutoDUKRlIjQ4xuWPan0smAEQGU95Ul9YJ9RMXwnRxldKcvwLGGJ+a5PskM5pyRUi2t8WSucYeqeLPk09xaWeA3dlWyi7BWI0JsWbVlYZLZI0wBOKb0F6gOPY1wTQIDAQAB"

    // برای عیب‌یابی روشن بمونه؛ قبل از انتشار نهایی false کن
    const val DEBUG_LOG = true
}
