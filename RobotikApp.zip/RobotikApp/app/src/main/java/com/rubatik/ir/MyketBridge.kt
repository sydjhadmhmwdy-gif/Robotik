package com.rubatik.ir

import android.app.Activity
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.webkit.JavascriptInterface
import android.webkit.WebView
import ir.myket.billingclient.util.IabHelper
import ir.myket.billingclient.util.IabResult
import ir.myket.billingclient.util.Inventory
import org.json.JSONArray
import org.json.JSONObject

private typealias Task = (done: () -> Unit) -> Unit

/**
 * پل بین صفحه‌ی HTML و خرید مایکت. صفحه این سه تابع رو صدا می‌زنه:
 *   MyketBridge.purchase(sku)  → onMyketPurchase(sku, success, message)
 *   MyketBridge.consume(sku)   → onMyketConsume(sku, success, message)
 *   MyketBridge.query()        → onMyketInventory(jsonString)   { ok, owned:[...], message }
 * کتابخونه‌ی مایکت هم‌زمان فقط یک درخواست قبول می‌کنه، برای همین همه‌چیز توی یه صف اجرا می‌شه.
 */
class MyketBridge(private val activity: Activity, private val webView: WebView) {

    companion object {
        private const val TAG = "MyketBridge"
        private const val RC_PURCHASE = 10001

        const val SKU_VIP = "VIP.toket"          // دائمی، مصرف نمی‌شه
        const val SKU_SERVER = "Server_mm"       // مصرفی
        const val SKU_SERVER_VIP = "Server.oo"   // مصرفی (قیمت تخفیف‌خورده‌ی کاربر VIP)

        private val ALL_SKUS = listOf(SKU_VIP, SKU_SERVER, SKU_SERVER_VIP)
        private val CONSUMABLE_SKUS = setOf(SKU_SERVER, SKU_SERVER_VIP)

        private const val RESPONSE_USER_CANCELED = 1
        private const val RESPONSE_ITEM_ALREADY_OWNED = 7
        private const val HELPER_USER_CANCELLED = -1005
        private const val PURCHASE_STATE_PURCHASED = 0
    }

    private val main = Handler(Looper.getMainLooper())
    private var helper: IabHelper? = null
    private var ready = false

    // ---------- صف اجرا ----------
    private val queue = ArrayDeque<Task>()
    private var busy = false

    private fun enqueue(task: Task) {
        main.post {
            queue.addLast(task)
            pump()
        }
    }

    private fun pump() {
        if (busy) return
        val task = queue.removeFirstOrNull() ?: return
        busy = true
        var finished = false
        lateinit var watchdog: Runnable
        val done: () -> Unit = {
            if (!finished) {
                finished = true
                main.removeCallbacks(watchdog)
                busy = false
                pump()
            }
        }
        // اگه به هر دلیلی یه عملیات هیچ‌وقت تموم نشد، صف برای همیشه قفل نمونه
        watchdog = Runnable { done() }
        main.postDelayed(watchdog, 10 * 60 * 1000L)
        try {
            task(done)
        } catch (e: Exception) {
            Log.e(TAG, "task failed", e)
            done()
        }
    }

    // ---------- اتصال به سرویس مایکت ----------
    private fun withHelper(onError: (String) -> Unit, done: () -> Unit, block: (IabHelper) -> Unit) {
        val current = helper
        if (current != null && ready) {
            block(current)
            return
        }
        if (MyketConfig.RSA_KEY.startsWith("PUT_")) {
            onError("rsa_key_missing")
            done()
            return
        }
        val h = current ?: IabHelper(activity, MyketConfig.RSA_KEY).also {
            it.enableDebugLogging(MyketConfig.DEBUG_LOG)
            helper = it
        }
        h.startSetup(IabHelper.OnIabSetupFinishedListener { result ->
            if (!result.isSuccess) {
                // دفعه‌ی بعد از اول امتحان کنه
                try { h.disposeWhenFinished() } catch (e: Exception) {}
                helper = null
                ready = false
                onError("myket_unavailable: " + (result.message ?: ""))
                done()
            } else {
                ready = true
                block(h)
            }
        })
    }

    // ---------- توابعی که صفحه صدا می‌زنه ----------
    @JavascriptInterface
    fun purchase(sku: String) = enqueue { done -> doPurchase(sku, done) }

    @JavascriptInterface
    fun consume(sku: String) = enqueue { done -> doConsume(sku, done) }

    @JavascriptInterface
    fun query() = enqueue { done -> doQuery(done) }

    // ---------- خرید ----------
    private fun doPurchase(sku: String, done: () -> Unit) {
        if (sku !in ALL_SKUS) {
            emitPurchase(sku, false, "unknown_sku")
            done()
            return
        }
        withHelper(onError = { emitPurchase(sku, false, it) }, done = done) { h ->
            try {
                val payload = java.util.UUID.randomUUID().toString()
                h.launchPurchaseFlow(
                    activity, sku, RC_PURCHASE,
                    IabHelper.OnIabPurchaseFinishedListener { result, purchase ->
                        when {
                            result.isSuccess && purchase != null &&
                                purchase.sku == sku && purchase.purchaseState == PURCHASE_STATE_PURCHASED ->
                                emitPurchase(sku, true, "")
                            // قبلاً خریده و هنوز مصرف نشده (مثلاً اپ وسط کار بسته شده بود): همون رو به‌عنوان خرید موفق حساب کن
                            result.response == RESPONSE_ITEM_ALREADY_OWNED ->
                                emitPurchase(sku, true, "already_owned")
                            isCanceled(result) -> emitPurchase(sku, false, "canceled")
                            else -> emitPurchase(sku, false, result.message ?: "purchase_failed")
                        }
                        done()
                    },
                    payload
                )
            } catch (e: Exception) {
                Log.e(TAG, "launchPurchaseFlow failed", e)
                emitPurchase(sku, false, e.message ?: "launch_failed")
                done()
            }
        }
    }

    // ---------- استعلام خریدهای مصرف‌نشده ----------
    private fun doQuery(done: () -> Unit) {
        withHelper(onError = { emitInventory(false, emptyList(), it) }, done = done) { h ->
            try {
                h.queryInventoryAsync(false, ALL_SKUS, null,
                    IabHelper.QueryInventoryFinishedListener { result, inv ->
                        if (result.isFailure || inv == null) {
                            emitInventory(false, emptyList(), result.message ?: "query_failed")
                        } else {
                            emitInventory(true, ownedSkus(inv), "")
                        }
                        done()
                    })
            } catch (e: Exception) {
                Log.e(TAG, "queryInventoryAsync failed", e)
                emitInventory(false, emptyList(), e.message ?: "query_failed")
                done()
            }
        }
    }

    // ---------- مصرف کردن (فقط دو محصول سرور؛ بلیط VIP هرگز) ----------
    private fun doConsume(sku: String, done: () -> Unit) {
        if (sku !in CONSUMABLE_SKUS) {
            emitConsume(sku, false, "not_consumable")
            done()
            return
        }
        withHelper(onError = { emitConsume(sku, false, it) }, done = done) { h ->
            try {
                h.queryInventoryAsync(false, ALL_SKUS, null,
                    IabHelper.QueryInventoryFinishedListener { result, inv ->
                        val purchase = if (result.isSuccess) inv?.getPurchase(sku) else null
                        when {
                            !result.isSuccess || inv == null -> {
                                emitConsume(sku, false, result.message ?: "query_failed")
                                done()
                            }
                            purchase == null -> {          // چیزی برای مصرف کردن نیست
                                emitConsume(sku, true, "not_owned")
                                done()
                            }
                            else -> h.consumeAsync(purchase,
                                IabHelper.OnConsumeFinishedListener { _, res ->
                                    emitConsume(sku, res.isSuccess, res.message ?: "")
                                    done()
                                })
                        }
                    })
            } catch (e: Exception) {
                Log.e(TAG, "consume failed", e)
                emitConsume(sku, false, e.message ?: "consume_failed")
                done()
            }
        }
    }

    // ---------- کمکی‌ها ----------
    private fun ownedSkus(inv: Inventory): List<String> = ALL_SKUS.filter { sku ->
        val p = inv.getPurchase(sku)
        p != null && p.purchaseState == PURCHASE_STATE_PURCHASED
    }

    private fun isCanceled(r: IabResult): Boolean =
        r.response == HELPER_USER_CANCELLED || r.response == RESPONSE_USER_CANCELED ||
            (r.message ?: "").contains("cancel", ignoreCase = true)

    fun handleActivityResult(requestCode: Int, resultCode: Int, data: Intent?): Boolean =
        helper?.handleActivityResult(requestCode, resultCode, data) ?: false

    fun dispose() {
        try { helper?.disposeWhenFinished() } catch (e: Exception) {}
        helper = null
        ready = false
    }

    // ---------- برگردوندن نتیجه به صفحه ----------
    private fun q(s: String) = JSONObject.quote(s)

    private fun js(code: String) {
        webView.post { webView.evaluateJavascript(code, null) }
    }

    private fun emitPurchase(sku: String, ok: Boolean, msg: String) =
        js("if(window.onMyketPurchase)onMyketPurchase(${q(sku)},$ok,${q(msg)});")

    private fun emitConsume(sku: String, ok: Boolean, msg: String) =
        js("if(window.onMyketConsume)onMyketConsume(${q(sku)},$ok,${q(msg)});")

    private fun emitInventory(ok: Boolean, owned: List<String>, msg: String) {
        val json = JSONObject().put("ok", ok).put("owned", JSONArray(owned)).put("message", msg).toString()
        js("if(window.onMyketInventory)onMyketInventory(${q(json)});")
    }
}
